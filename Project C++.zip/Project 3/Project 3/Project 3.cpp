#include <iostream>  
#include <iomanip>
#include <string>
using namespace std;
int main(){
	

	
	/*cout << "\" Information Technology \'c\' ? \" " << endl ;
	cout << setw (65) << " Hello " << endl ;
	cout << setw (76) << " \" This is Turbo C++ Program \" " << endl ;
	cout << setw (69) << " It's very easy " << endl ;
	cout << setw (74) << " It's high level language " << endl ;
	cout << setw (68) << " I love C++ " << endl ;
	cout << "                                                                                                 " << endl ;
	cout << " A = \101 = \x41 \n" ;
	cout << " A = " << (char)65 << endl ;
	cout << "                                                                                                 " << endl ;
	cout << " My Nickname is = " <<(char)71 << (char)65 << (char)77 << (char)69  << endl ;
	cout << "                                                                                                 " << endl ;
	unsigned short x = 65535 ;
	cout << "char \t= " << sizeof(x) << " bytes" << x << endl ;
	cout << "                                                                                                 " << endl ;
	cout << "Hexa constant 0x23 is " << 0x23 << " decimal\n";
	cout << 230.E+3 << endl;
	float j = 10 ;
	int i = 20 ;
	char c = 30 ;
	double d = 40;
	cout << "j value is " << j << endl;
	cout << "i value is " << i << endl;
	cout << "c value is " << c << endl;
	cout << "d value is " << d << endl;

	cout << "                                                                                                 " << endl ;

	*/
	string Name = " Nattapon ";
	float Scores1 = 80 ;
	float Scores2 = 85 ;
	char Grade = 'A' ;
	float GPA = 2.46;
	cout << "      My name is : " << Name << endl ;
	cout << "    My scores is : " << Scores1 << " Points" <<  endl ;
	cout << "    My scores is : " << Scores2 << " Points" <<  endl ;
	cout << " Total Scores is : " << Scores1+Scores2 << " Points " << endl ;
	cout << "           Grade : " << Grade << endl ;
	cout << "             GPA : " << GPA << endl ;



}